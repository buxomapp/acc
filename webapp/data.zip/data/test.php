<?php


 echo date("z", strtotime("2020/01/07"));
    
?>